package com.example.android.quiz_app;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by mus on 7/4/17.
 */

public class Adapter extends ArrayAdapter<List> {

    /**
     * This is our own custom constructor (it doesn't mirror a superclass constructor).
     * The context is used to inflate the layout file, and the list is the data we want
     * to populate into the lists.
     *
     * @param context       The current context. Used to inflate the layout file.
     * @param list A List of AndroidFlavor objects to display in a list
     */

    public Adapter(Activity context, ArrayList<List> list) {
        // Here, we initialize the ArrayAdapter's internal storage for the context and the list.
        // the second argument is used when the ArrayAdapter is populating a single TextView.
        // Because this is a custom adapter for two TextViews and an ImageView, the adapter is not
        // going to use this second argument, so it can be any value. Here, we used 0.
        super(context, 0, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.question_template, parent, false);
        }
        // Get the {@link AndroidFlavor} object located at this position in the list
        List currentList = getItem(position);

        //find the id
        TextView headView = (TextView)listItemView.findViewById(R.id.head);
        headView.setText(currentList.getHead());


        ImageView imageView = (ImageView) listItemView.findViewById(R.id.image);
        imageView.setImageResource(currentList.getImage());

        TextView questionView = (TextView) listItemView.findViewById(R.id.thequestion);
        questionView.setText(currentList.getQuestion());

        TextView choiceaView = (TextView) listItemView.findViewById(R.id.answer1);
        choiceaView.setText(currentList.getChoiceA());

        TextView choicebView = (TextView) listItemView.findViewById(R.id.answer2);
        choicebView.setText(currentList.getChoiceB());

        TextView choicecView = (TextView) listItemView.findViewById(R.id.answer3);
        choicecView.setText(currentList.getChoiceC());

        TextView choicedView = (TextView) listItemView.findViewById(R.id.answer4);
        choicedView.setText(currentList.getChoiceD());

        TextView nextView = (TextView) listItemView.findViewById(R.id.nextview);
        nextView.setText(currentList.getNext());



        return listItemView;
    }
}

